#include <stdio.h>

int main(void)
{    printf("Baturin Artyom Andreevich i914B.\n");
    return 1;
}